﻿namespace PasswordProtectedJail
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Welcomesign = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.ClearAll_Button = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.PHNUmberEntry1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SecondTextBob = new System.Windows.Forms.TextBox();
            this.FirstText = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.ClearSel_Button = new System.Windows.Forms.Button();
            this.SaveFile_Button = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.LoadFile_Button = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.DelOne_Button = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.InputB = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Welcomesign
            // 
            this.Welcomesign.AutoSize = true;
            this.Welcomesign.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Welcomesign.Location = new System.Drawing.Point(182, 45);
            this.Welcomesign.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Welcomesign.MaximumSize = new System.Drawing.Size(520, 46);
            this.Welcomesign.MinimumSize = new System.Drawing.Size(133, 46);
            this.Welcomesign.Name = "Welcomesign";
            this.Welcomesign.Size = new System.Drawing.Size(157, 46);
            this.Welcomesign.TabIndex = 0;
            this.Welcomesign.Text = "Welcome: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(700, 728);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 25);
            this.label10.TabIndex = 29;
            this.label10.Text = "Result";
            // 
            // ClearAll_Button
            // 
            this.ClearAll_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ClearAll_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearAll_Button.Location = new System.Drawing.Point(359, 468);
            this.ClearAll_Button.Margin = new System.Windows.Forms.Padding(4);
            this.ClearAll_Button.Name = "ClearAll_Button";
            this.ClearAll_Button.Size = new System.Drawing.Size(125, 82);
            this.ClearAll_Button.TabIndex = 6;
            this.ClearAll_Button.Text = "Clear All  Data";
            this.ClearAll_Button.UseVisualStyleBackColor = true;
            this.ClearAll_Button.Click += new System.EventHandler(this.button1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(563, 888);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 25);
            this.label8.TabIndex = 27;
            this.label8.Text = "Number";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(595, 794);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 25);
            this.label7.TabIndex = 26;
            this.label7.Text = "Last";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(55, 399);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 25);
            this.label5.TabIndex = 25;
            this.label5.Text = "Number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(87, 331);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 25);
            this.label4.TabIndex = 24;
            this.label4.Text = "Last";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(81, 259);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 25);
            this.label3.TabIndex = 23;
            this.label3.Text = "FIrst ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(686, 876);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.MaximumSize = new System.Drawing.Size(200, 38);
            this.label2.MinimumSize = new System.Drawing.Size(107, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 38);
            this.label2.TabIndex = 22;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // PHNUmberEntry1
            // 
            this.PHNUmberEntry1.Location = new System.Drawing.Point(179, 399);
            this.PHNUmberEntry1.Margin = new System.Windows.Forms.Padding(4);
            this.PHNUmberEntry1.Name = "PHNUmberEntry1";
            this.PHNUmberEntry1.Size = new System.Drawing.Size(256, 30);
            this.PHNUmberEntry1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(686, 781);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.MaximumSize = new System.Drawing.Size(200, 38);
            this.label1.MinimumSize = new System.Drawing.Size(107, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 38);
            this.label1.TabIndex = 20;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // SecondTextBob
            // 
            this.SecondTextBob.Location = new System.Drawing.Point(179, 331);
            this.SecondTextBob.Margin = new System.Windows.Forms.Padding(4);
            this.SecondTextBob.Name = "SecondTextBob";
            this.SecondTextBob.Size = new System.Drawing.Size(256, 30);
            this.SecondTextBob.TabIndex = 2;
            // 
            // FirstText
            // 
            this.FirstText.Location = new System.Drawing.Point(179, 259);
            this.FirstText.Margin = new System.Windows.Forms.Padding(4);
            this.FirstText.Name = "FirstText";
            this.FirstText.Size = new System.Drawing.Size(256, 30);
            this.FirstText.TabIndex = 1;
            // 
            // listBox1
            // 
            this.listBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.HorizontalScrollbar = true;
            this.listBox1.ItemHeight = 25;
            this.listBox1.Location = new System.Drawing.Point(600, 229);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4);
            this.listBox1.Name = "listBox1";
            this.listBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.listBox1.Size = new System.Drawing.Size(241, 279);
            this.listBox1.TabIndex = 16;
            this.listBox1.TabStop = false;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // ClearSel_Button
            // 
            this.ClearSel_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ClearSel_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearSel_Button.Location = new System.Drawing.Point(200, 468);
            this.ClearSel_Button.Margin = new System.Windows.Forms.Padding(4);
            this.ClearSel_Button.Name = "ClearSel_Button";
            this.ClearSel_Button.Size = new System.Drawing.Size(125, 83);
            this.ClearSel_Button.TabIndex = 5;
            this.ClearSel_Button.Text = "Clear Selected ";
            this.ClearSel_Button.UseVisualStyleBackColor = true;
            this.ClearSel_Button.Click += new System.EventHandler(this.button2_Click);
            // 
            // SaveFile_Button
            // 
            this.SaveFile_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SaveFile_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveFile_Button.Location = new System.Drawing.Point(318, 635);
            this.SaveFile_Button.Margin = new System.Windows.Forms.Padding(4);
            this.SaveFile_Button.Name = "SaveFile_Button";
            this.SaveFile_Button.Size = new System.Drawing.Size(117, 60);
            this.SaveFile_Button.TabIndex = 8;
            this.SaveFile_Button.Text = "Save Files ";
            this.SaveFile_Button.UseVisualStyleBackColor = true;
            this.SaveFile_Button.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(50, 647);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(241, 35);
            this.textBox1.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(80, 588);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(141, 25);
            this.label6.TabIndex = 33;
            this.label6.Text = "Name of Save ";
            // 
            // listBox2
            // 
            this.listBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 25;
            this.listBox2.Location = new System.Drawing.Point(50, 780);
            this.listBox2.Margin = new System.Windows.Forms.Padding(4);
            this.listBox2.Name = "listBox2";
            this.listBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.listBox2.Size = new System.Drawing.Size(261, 154);
            this.listBox2.TabIndex = 34;
            this.listBox2.TabStop = false;
            this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // LoadFile_Button
            // 
            this.LoadFile_Button.Cursor = System.Windows.Forms.Cursors.AppStarting;
            this.LoadFile_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoadFile_Button.Location = new System.Drawing.Point(318, 780);
            this.LoadFile_Button.Margin = new System.Windows.Forms.Padding(4);
            this.LoadFile_Button.Name = "LoadFile_Button";
            this.LoadFile_Button.Size = new System.Drawing.Size(117, 60);
            this.LoadFile_Button.TabIndex = 9;
            this.LoadFile_Button.Text = "Load Files";
            this.LoadFile_Button.UseVisualStyleBackColor = true;
            this.LoadFile_Button.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(724, 45);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(104, 46);
            this.button5.TabIndex = 36;
            this.button5.Text = "Log Out";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // DelOne_Button
            // 
            this.DelOne_Button.Cursor = System.Windows.Forms.Cursors.No;
            this.DelOne_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DelOne_Button.Location = new System.Drawing.Point(318, 876);
            this.DelOne_Button.Margin = new System.Windows.Forms.Padding(4);
            this.DelOne_Button.Name = "DelOne_Button";
            this.DelOne_Button.Size = new System.Drawing.Size(117, 60);
            this.DelOne_Button.TabIndex = 10;
            this.DelOne_Button.Text = "Del Single File";
            this.DelOne_Button.UseVisualStyleBackColor = true;
            this.DelOne_Button.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(667, 583);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(159, 30);
            this.textBox2.TabIndex = 37;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(536, 588);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 25);
            this.label9.TabIndex = 39;
            this.label9.Text = "Search for:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(86, 728);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(115, 25);
            this.label11.TabIndex = 40;
            this.label11.Text = "Saved Files";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(685, 174);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 29);
            this.label12.TabIndex = 41;
            this.label12.Text = "Data";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(224, 204);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(140, 29);
            this.label13.TabIndex = 42;
            this.label13.Text = "Create Data";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::PasswordProtectedJail.Properties.Resources.Mini_Jailbreaker_Logo;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(12, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(163, 131);
            this.pictureBox1.TabIndex = 43;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::PasswordProtectedJail.Properties.Resources.june_16_in_jail_monopoly;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(676, 635);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(117, 82);
            this.button1.TabIndex = 38;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // InputB
            // 
            this.InputB.BackgroundImage = global::PasswordProtectedJail.Properties.Resources.go_to_jail;
            this.InputB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.InputB.Cursor = System.Windows.Forms.Cursors.Hand;
            this.InputB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InputB.Location = new System.Drawing.Point(50, 468);
            this.InputB.Margin = new System.Windows.Forms.Padding(4);
            this.InputB.Name = "InputB";
            this.InputB.Size = new System.Drawing.Size(125, 82);
            this.InputB.TabIndex = 4;
            this.InputB.UseVisualStyleBackColor = true;
            this.InputB.Click += new System.EventHandler(this.InputB_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(828, 512);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(0, 20);
            this.label14.TabIndex = 44;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(740, 512);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(62, 20);
            this.label15.TabIndex = 45;
            this.label15.Text = "*Count:";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(931, 956);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.DelOne_Button);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.LoadFile_Button);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.SaveFile_Button);
            this.Controls.Add(this.ClearSel_Button);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.ClearAll_Button);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.PHNUmberEntry1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SecondTextBob);
            this.Controls.Add(this.InputB);
            this.Controls.Add(this.FirstText);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.Welcomesign);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximumSize = new System.Drawing.Size(953, 1011);
            this.MinimumSize = new System.Drawing.Size(926, 986);
            this.Name = "Form2";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Database";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Welcomesign;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button ClearAll_Button;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox PHNUmberEntry1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox SecondTextBob;
        private System.Windows.Forms.Button InputB;
        private System.Windows.Forms.TextBox FirstText;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button ClearSel_Button;
        private System.Windows.Forms.Button SaveFile_Button;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button LoadFile_Button;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button DelOne_Button;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
    }
}