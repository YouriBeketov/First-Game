﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Robbery
{
    }
class ReadTxTFiles
{
    static string EnterNameofFile(string x)
    {

        StreamReader myreader = new StreamReader(x);
        string information = "";
        while (information != null)
        {
            information = myreader.ReadLine();

            if (information != null)
            {/*
                    foreach (var letter in information)
                    {
                        Console.Write(letter);
                        System.Threading.Thread.Sleep(10);
                    }
                     */
                Console.WriteLine(information);
            }
        }
        return (x);
    }

        class PasswordBankProtection
    {
        public static void  PasswordGenerator()
            {
                Random random = new Random();
                int randomNumber0 = random.Next(0, 10);
                int randomNumber1 = random.Next(0, 10);
                int randomNumber2 = random.Next(0, 10);
                int randomNumber3 = random.Next(0, 10);
                
                string RNumberStr = randomNumber0.ToString() + randomNumber1.ToString() + randomNumber2.ToString() + randomNumber3.ToString();

                TextWriter tw = new StreamWriter("ReadMePassword.txt");
                tw.Close();
                using (System.IO.StreamWriter file = new System.IO.StreamWriter("ReadMePassword.txt", true))
                {
                    file.WriteLine("{0} ", RNumberStr);

                }
      
            }
        public static string PWBProtection(string x)
        {
            int GPCount = 0;
            string password = ReadTxTFiles.EnterNameofFile("ReadMePassword.txt");
            foreach (var number in x)
            {
                if (password.Contains(number))
                {
                    int PIdex = password.IndexOf(number);
                    Console.WriteLine("Hackers log:");
                    Console.WriteLine("Found! {0} in postition {1}",number,PIdex+1);
                    
                    GPCount++;
                }  
                else
                {
                    Console.WriteLine("Hackers log:");
                    Console.WriteLine("Could not find {0} in the password. Try another number!", number);

                }
            }
            string GPCOUNTstring = GPCount.ToString();
            return GPCOUNTstring;
        }
    }
    class TimeInsideBank
    {
        public float BankLobby { get; set; }
        public float BankVault {get;set;}
        public float BankSecurity {get;set;}
    }
    class makefile
    {
        public static void initialize()
        {
            TextWriter tw = new StreamWriter("PlayerDescision.txt");
            tw.Close();
        }
    }

class MakeItCool
{
    public static void PrintLine(string line)
    {
        foreach (var letter in line)
        {
            Console.Write(letter);
            System.Threading.Thread.Sleep(50);
        }
    }
}
    class readfiles 
    {
        public static string Readuserchoicesfromfile()
        {
            StreamReader myReader = new StreamReader("RandomPassword.txt");
            string data = "";
            
            while (data != null)
            {
                data = myReader.ReadLine();
                
            }
            myReader.Close();
            return data;}
     }
    class Robbers
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Proffession { get; set; }
        public int Experienceoutof10 { get; set; }
        public int Percentageofpay { get; set; }
        public int Undercover { get; set; }
    }
    public class TImelimit
    {
         List<Robbers> Robbersselected = new List<Robbers>();    
    }
    class SavedescisiontoFile
    {
        public static List<Robbers> savetotxt()
        {
            List<Robbers> Savedcollection = new List<Robbers>();
            TextWriter tw = new StreamWriter("PlayerDescision.txt");

            /*  using (System.IO.StreamWriter file = new System.IO.StreamWriter("PlayerDescision.txt", true))
             {
                 file.WriteLine(Savedcollection);
                 tw.Close();
             }
             * */
              tw.Close();
              return Savedcollection;    
        }
        
    }
    
        class Program
        {
            static void Main(string[] args)
            {
                bool startgame = true;
                while (startgame)
                {
                    Console.WriteLine("Play or Exit ?");
                    string startgameuser = Console.ReadLine();
                    switch (startgameuser.ToUpper())
                    {
                        case "PLAY":
                            {

                                makefile.initialize();

                                PasswordBankProtection.PasswordGenerator();
                                ReadTxTFiles.EnterNameofFile("Introduction.txt");
                                Console.ReadLine();
                                List<Robbers> listselected = new List<Robbers>();
                                List<TimeInsideBank> TimeSpentByPlayer = new List<TimeInsideBank>();
                                List<Robbers> listofRobbers = new List<Robbers>()
          {new Robbers{ID=1, Name="John  ",Proffession="Hacker", Experienceoutof10=3,Percentageofpay=10, Undercover=0},
            new Robbers{ID=2,Name ="Martin", Proffession="Hacker",Experienceoutof10=4, Percentageofpay=18, Undercover=0},
            new Robbers{ID=3,Name ="Julien", Proffession="Hacker",Experienceoutof10=6, Percentageofpay=23, Undercover=0},
            new Robbers{ID=4,Name ="Bob  ", Proffession="Hacker",Experienceoutof10=7, Percentageofpay=27, Undercover=1},
           new Robbers{ID=5,Name ="Alex   ", Proffession="Hakcer",Experienceoutof10=8, Percentageofpay=35, Undercover=0},
           new Robbers{ID=6,Name= "Patric ",Proffession="Gunmen",Experienceoutof10=2,Percentageofpay=10, Undercover=0},
           new Robbers{ID=7,Name= "Chris ",Proffession="Gunmen",Experienceoutof10=4,Percentageofpay=18, Undercover=1},
           new Robbers{ID=8,Name= "Luis   ",Proffession="Gunmen",Experienceoutof10=5,Percentageofpay=25, Undercover=0},
           new Robbers{ID=9,Name= "Peter  ",Proffession="Gunmen",Experienceoutof10=6,Percentageofpay=31, Undercover=0},
           new Robbers{ID=10,Name="Paul  ",Proffession="Gunmen",Experienceoutof10=7, Percentageofpay=35, Undercover=0},
           new Robbers{ID=11,Name="Abdel ",Proffession="Gunmen", Experienceoutof10=8, Percentageofpay=30, Undercover=1},
           new Robbers{ID=12,Name="Shawn ",Proffession="Driver", Experienceoutof10= 2, Percentageofpay= 5, Undercover=0},
           new Robbers{ID=13,Name="Kais ",Proffession="Driver", Experienceoutof10= 5, Percentageofpay= 12, Undercover=1},
           new Robbers{ID=14,Name="David",Proffession="Driver", Experienceoutof10= 7, Percentageofpay= 25, Undercover=0},
           new Robbers{ID=15,Name="Steven",Proffession="Driver", Experienceoutof10= 4, Percentageofpay= 20, Undercover=0}
           };
                                foreach (var robber in listofRobbers)
                                {
                                    Console.WriteLine("ID : {4},Name: {0}, Proffession: {1} Experience: {2}, PercentageOfPay: {3}", robber.Name, robber.Proffession, robber.Experienceoutof10, robber.Percentageofpay, robber.ID);
                                }
                                
                                string[] collectionuserdoublecheck = new string[4];
                                int collectioncount = 1;
                                int Countofselection = 0;
                                bool RobbersSelection = true;
                                int counttosave = 0;
                                while (RobbersSelection)
                                {
                                    if (Countofselection == 3)
                                    {
                                        Console.WriteLine("You are now ready for your journey. Will it be jail or eternal wealth ");
                                        Console.WriteLine("Press Enter to start.");
                                        RobbersSelection = false;
                                    }
                                    else
                                    {
                                        int lengtheoflist = listofRobbers.Count;
                                        Console.WriteLine("Please select 3 robbers.");
                                        Console.WriteLine("Please enter candidate ID between 1 and {0}", lengtheoflist);
                                        Console.WriteLine(" Enter one candidate at a time.");
                                        string userselection = Console.ReadLine();


                                        if (collectionuserdoublecheck.Contains(userselection))
                                        // if (userselectioncheckdouble.Contains(userselection))
                                        {
                                            Console.WriteLine("You have already selected this person");
                                            Console.WriteLine("Press Enter");
                                        }
                                        else
                                        {

                                            //userselectioncheckdouble = userselectioncheckdouble + userselection;//problem here 
                                            /* int checkifint=0;
                                             var checkifinlist = userselection[checkifint + 1];
                                             if ( userselection in checkifinlist)
                                             */
                                            int userselectionint;
                                            if (int.TryParse(userselection, out userselectionint))
                                            {
                                                /*
                                                var Robberselecter = from Robberselected in listofRobbers
                                                                      where Robberselected.ID == userselectionint
                                                                      select Robberselected;
                                                 foreach (var Name in Robberselecter)
                                                 {
                                                    Console.WriteLine("You selected : {0}",Name); 
                                                 }
                                                 */
                                                if (userselectionint > 0 && userselectionint <= lengtheoflist)
                                                {
                                                    collectionuserdoublecheck[collectioncount] = userselection;
                                                    collectioncount++; ;
                                                    Console.WriteLine("You picked: {0}, You inform him of the mission. He now knows too much.", listofRobbers[userselectionint - 1].Name);
                                                    Console.WriteLine("Press Enter.");
                                                    Countofselection++;
                                                    listselected.Add(listofRobbers[userselectionint - 1]);
                                                    using (System.IO.StreamWriter file = new System.IO.StreamWriter("PlayerDescision.txt", true))
                                                    {
                                                        var Robberselecter2 = from Robberselected2 in listselected

                                                                              select Robberselected2;
                                                        foreach (var Name in Robberselecter2)
                                                        {
                                                            file.WriteLine("Selection {0}, {1}, {2}", Name.Name, Name.Percentageofpay, Name.Proffession);
                                                            counttosave++;
                                                        }

                                                      
                                                    }
                                                    
                                                }
                                                else
                                                {
                                                    Console.WriteLine("You did not selected a good one");
                                                    Console.WriteLine("Press Enter");
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine("You did not selected a good one");
                                                Console.WriteLine("Press Enter");
                                            }
                                        }
                                    }
                                    Console.ReadLine();
                                }

                                var Robberselecter = from Robberselected in listselected

                                                     select Robberselected;
                                foreach (var Name in Robberselecter)
                                {
                                    Console.WriteLine("You selected : {0}. He is a {1} with {2} experience and he will take {3}% of the take.", Name.Name, Name.Proffession,Name.Experienceoutof10,Name.Percentageofpay);
                                }
                                Console.WriteLine("Press Enter");
                                Console.ReadLine();

                                bool timealocated = true;
                                bool goodtimealocated = true;
                                float TimeGivenToPlayerInSeconds = 900;
                                float TimeGivenToBankLobby = 0;
                                float TimeGivenToSecurityToAdd = 0;
                                float TimeGivenToSecurity = 0;
                                float timeGIvenToVaultToAdd = 0;
                                float TImeGivenToBankVault = 0;
                                float TimeGivenToBankLobbyToAdd=0;
                                float TimeGivenToDriver=0;
                                float TimeCountForLobbyDisplay = 0;
                                float TimeCountForSecurityDisplay = 0;
                                float TimeCountForVaultDisplay = 0;
                                Random random = new Random();
                                int randomNumber0 = random.Next(0, 10);
                                int randomNumber1 = random.Next(0, 10);
                                int randomNumber2 = random.Next(0, 10);
                                int randomNumber3 = random.Next(0, 10);

                                string finalnumber = randomNumber0.ToString() + randomNumber1.ToString() + randomNumber2.ToString() + randomNumber3.ToString();
                                while (goodtimealocated)
                                {
                                    while (timealocated)
                                    {
                                        if (TimeGivenToPlayerInSeconds == 0.0)
                                        {
                                            Console.WriteLine("All the time has been alocated. \n You are now ready to go to the bank.");
                                            goodtimealocated = false;
                                            Console.ReadLine();
                                        }

                                        // int timeleftofRObbery = 15;

                                        Console.WriteLine("You have a 15 minute time frame to get out of the bank safely.\nHow will you spend it? \nTime Left: {0} seconds.\nYour mission will not start in till time left is at 0.", TimeGivenToPlayerInSeconds);
                                        Console.WriteLine("Please select one of the following three option and allocated time to it, once all the time has been alocated, the robbery will begin");
                                        Console.WriteLine("1. BankLobby");
                                        Console.WriteLine("2. Security");
                                        Console.WriteLine("3. Bank Vault");
                                        Console.WriteLine("4. Go to Bank");

                                        string answeridquestion = Console.ReadLine();
                                        switch (answeridquestion.ToUpper())
                                        {
                                            case "1":
                                            case "BANKLOBBY":
                                                {
                                                    Console.WriteLine("You have allocated {0} seconds to nutralizing the lobby", TimeCountForLobbyDisplay);
                                                    Console.WriteLine("Enter the amount of time (Enter negative amount to take time away)");
                                                    Console.WriteLine("How much time in seconds for this section ?");

                                                    string userSBankLobby = Console.ReadLine();
                                                    
                                                    if (float.TryParse(userSBankLobby, out TimeGivenToBankLobbyToAdd))
                                                    {
                                                        if (TimeGivenToPlayerInSeconds < TimeGivenToBankLobbyToAdd)
                                                        {
                                                            Console.WriteLine("You have alocated too much time. Try again\nPress Enter.");
                                                            Console.ReadLine();
                                                            break;

                                                        }
                                                        else
                                                        {
                                                            TimeCountForLobbyDisplay = TimeCountForLobbyDisplay + TimeGivenToBankLobbyToAdd;
                                                            TimeGivenToPlayerInSeconds = TimeGivenToPlayerInSeconds - TimeGivenToBankLobbyToAdd;
                                                            TimeGivenToBankLobby += TimeGivenToBankLobbyToAdd;
                                                            Console.WriteLine("{0} seconds have been added to this section", TimeGivenToBankLobbyToAdd);
                                                            Console.WriteLine("Press enter");
                                                            Console.ReadLine();
                                                            break;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        Console.WriteLine("I did not underdstand");
                                                        Console.WriteLine("Press enter");
                                                        Console.ReadLine();
                                                        break;
                                                    }
                                                }

                                            case "2":
                                            case "SECURITY":
                                                {
                                                   
                                                        Console.WriteLine("You have allocated {0} seconds to nutralizing the security.", TimeCountForSecurityDisplay);
                                                        Console.WriteLine("Enter the amount of time (Enter negative amount to take time away)");
                                                        Console.WriteLine("How much time in seconds ?");

                                                        string userSBankSecurity = Console.ReadLine();
                                                      
                                                        if (float.TryParse(userSBankSecurity, out TimeGivenToSecurityToAdd))
                                                        {
                                                            if (TimeGivenToPlayerInSeconds < TimeGivenToSecurityToAdd)
                                                    {
                                                        Console.WriteLine("You have alocated too much time. Try again\nPress Enter.");
                                                        Console.ReadLine();
                                                        break;

                                                    }
                                                    else
                                                    {
                                                        TimeCountForSecurityDisplay = TimeCountForSecurityDisplay + TimeGivenToSecurityToAdd;
                                                        TimeGivenToPlayerInSeconds = TimeGivenToPlayerInSeconds - TimeGivenToSecurityToAdd;
                                                        TimeGivenToSecurity += TimeGivenToSecurityToAdd;
                                                        Console.WriteLine("{0} seconds have been added to this section", TimeGivenToSecurityToAdd);
                                                            Console.WriteLine("Press enter");
                                                            Console.ReadLine();
                                                        }
                                                        }
                                                        else
                                                        {
                                                            Console.WriteLine("I did not underdstand");
                                                            Console.WriteLine("Press enter");
                                                            Console.ReadLine();
                                                        }
                                                        break;
                                                    
                                                }
                                            case "3":
                                            case "VAULT":
                                                {

                                                    Console.WriteLine("You have allocated {0} seconds to nutralizing the vault.", TimeCountForVaultDisplay);
                                                    Console.WriteLine("Enter the amount of time (Enter negative amount to take time away)");
                                                    Console.WriteLine("How much time in seconds ?");

                                                    string userSBankVault = Console.ReadLine();
                                                    if (float.TryParse(userSBankVault, out timeGIvenToVaultToAdd))
                                                    {
                                                        if (TimeGivenToPlayerInSeconds < timeGIvenToVaultToAdd)
                                                        {
                                                            Console.WriteLine("You have alocated too much time. Try again\nPress Enter.");
                                                            Console.ReadLine();
                                                            break;

                                                        }
                                                        else
                                                        {
                                                            TimeCountForVaultDisplay = TimeCountForVaultDisplay +   timeGIvenToVaultToAdd;
                                                            TimeGivenToPlayerInSeconds = TimeGivenToPlayerInSeconds - timeGIvenToVaultToAdd;
                                                            TImeGivenToBankVault+=timeGIvenToVaultToAdd;
                                                            Console.WriteLine("{0} seconds have been added to this section", timeGIvenToVaultToAdd);
                                                            Console.WriteLine("Press enter");
                                                            Console.ReadLine();
                                                        }
                                                    }
                                                    else
                                                    {
                                                        Console.WriteLine("I did not underdstand");
                                                        Console.WriteLine("Press enter");
                                                        Console.ReadLine();
                                                    }
                                                    break;
                                                    
                                                }
                                            case "4":
                                            case "GO TO BANK":
                                                {
                                                    if (TimeGivenToPlayerInSeconds == 0)
                                                    {
                                                        MakeItCool.PrintLine("Your mission will soon begin \n");
                                                        Console.WriteLine("Press Enter");
                                                        Console.ReadLine();
                                                        ReadTxTFiles.EnterNameofFile("Level1.txt");
                                                        Console.ReadLine();
                                                        timealocated = false;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        Console.WriteLine("You are not ready!");
                                                        Console.WriteLine("Make sure the time left is equal to zero ");
                                                        Console.WriteLine("Press Enter");
                                                        Console.ReadLine();
                                                    }
                                                    break;
                                                }
                                            default:
                                                {
                                                    if (TimeGivenToPlayerInSeconds == 0)
                                                    {
                                                        Console.WriteLine("Please select option 4 to begin your robbery, or say 'Go to Bank'.");
                                                        Console.ReadLine();
                                                        break;
                                                    }
                                                    else if (TimeGivenToPlayerInSeconds < 0)
                                                    {
                                                        Console.WriteLine("You have allocated too much time to your mission. Please choose one of the first three options and take away time from it by entering a negative amount.");
                                                        Console.ReadLine();
                                                        break;
                                                    }
                                                    else
                                                        Console.WriteLine("What are you doing!?!- You loose 30 seconds thinking about it");
                                                    TimeGivenToPlayerInSeconds = TimeGivenToPlayerInSeconds - 30;
                                                    Console.ReadLine();
                                                    break;
                                                }
                                        }
                                    }
                                }
                                /*List<Robbers>savedtogame= new List<Robbers>();
                                var savedchoice = from saved in readfiles.Readuserchoicesfromfile()
                                                      select saved;
                                int choiceindex = 0;
                                foreach (var choice in savedchoice)
                                {
                                    savedtogame.Add(choice[0-choiceindex]);
                                    choiceindex++;
                                }
                                 */
                                
                                bool HackerDidJob;
                                bool VaultBrokenIn;
                                bool GunmenDidJob;
                                bool HurryTime=false;
                                int MoneyFromGrandMa = 0;
                                int Yourtake = 0;
                                //bool DriverDidJob;// not used yet - might not need it. 
                                int undercovecheck = 0;

                                var checkforgun = from guncheck in listselected
                                                  where guncheck.Proffession == "Gunmen"
                                                  select guncheck;

                                foreach (var Robberstats in checkforgun)
                                {
                                    //Console.WriteLine(Robberstats.Undercover);
                                    int gunmenextrapoints = Robberstats.Experienceoutof10;
                                    int isgunmencop = Robberstats.Undercover;
                                    if (isgunmencop > 0)
                                    { undercovecheck++; }

                                    while (gunmenextrapoints != 0)
                                    {
                                        TimeGivenToBankLobby += 10;
                                        TImeGivenToBankVault += 10;
                                        gunmenextrapoints--;
                                    }
                                }
                                var checkforhacker = from hackercheck in listselected
                                                     where hackercheck.Proffession == "Hacker"
                                                     select hackercheck;
                                foreach (var hackerstats in checkforhacker)
                                {
                                    //Console.WriteLine(hackerstats.Undercover);
                                    int hackerextrapoints = hackerstats.Experienceoutof10;
                                    int ishackercop = hackerstats.Undercover;
                                    if (ishackercop > 0)
                                    { undercovecheck++; }
                                    while (hackerextrapoints != 0)
                                    {

                                        TimeGivenToSecurity += 8;
                                        TImeGivenToBankVault += 8;
                                        hackerextrapoints--;
                                    }
                                }
                                var checkfordriver = from drivercheck in listselected
                                                     where drivercheck.Proffession == "Driver"
                                                     select drivercheck;
                                foreach (var driverstats in checkfordriver)
                                {
                                    //Console.WriteLine(driverstats.Undercover);
                                    int driverextrapoint = driverstats.Experienceoutof10;
                                    int isdrivercop = driverstats.Undercover;
                                    if (isdrivercop > 0)
                                    { undercovecheck++; }
                                    while (driverextrapoint!=0)
                                    {
                                        TimeGivenToDriver += 10;
                                        driverextrapoint--;
                                    }                             
                                }
                                if (TimeGivenToSecurity <= 300.0)
                                {
                                    HackerDidJob = false;
                                    ReadTxTFiles.EnterNameofFile("HackerFail.txt");
                                    Console.ReadLine();
                                    ReadTxTFiles.EnterNameofFile("DriverFail.txt");
                                    Console.ReadLine();

                                    Console.WriteLine("You go to Jail !");
                                    Console.ReadLine();
                                    break;
                                }
                                else if (TimeGivenToSecurity > 300 && TimeGivenToSecurity < 370)
                                {
                                    Console.WriteLine("Your hacker has detected a txt being sent from the bank \nHe imidiately remembers that did not disable the phone connections and quickly does it.\n It speed things up for you.");
                                    ReadTxTFiles.EnterNameofFile("HackerG.txt");
                                    Console.ReadLine();
                                    HackerDidJob = true;
                                    HurryTime = true;
                                    Console.ReadLine();
                                }
                                else
                                {
                                    HackerDidJob = true;
                                    ReadTxTFiles.EnterNameofFile("HackerG.txt");
                                    Console.ReadLine();
                                }
                                if (TimeGivenToBankLobby < 370.0)
                                {
                                    GunmenDidJob = false;
                                    ReadTxTFiles.EnterNameofFile("GunmenFail.txt");
                                    Console.ReadLine();
                                    if (TimeGivenToDriver > 39)
                                    {
                                        ReadTxTFiles.EnterNameofFile("DriverG.txt");
                                        Console.ReadLine();
                                        Console.WriteLine("But you didn't get the money");
                                        Console.ReadLine();
                                        if (undercovecheck > 0)
                                        {
                                            ReadTxTFiles.EnterNameofFile("Undercover.txt");
                                            break;
                                        }
                                        break;
                                    }
                                    else
                                    {
                                        ReadTxTFiles.EnterNameofFile("DriverFail.txt");
                                        Console.ReadLine();
                                        Console.WriteLine("You go to JAIL !");
                                        Console.ReadLine();
                                        break;
                                    }   
                                }
                                else
                                {
                                    GunmenDidJob = true;
                                    ReadTxTFiles.EnterNameofFile("LobbyG.txt");
                                    Console.ReadLine();
                                }
                                if (TImeGivenToBankVault <= 329) 
                                {
                                    ReadTxTFiles.EnterNameofFile("VaultFail.txt");
                                    VaultBrokenIn = false;
                                    Console.ReadLine();
                                    if (HackerDidJob == true)
                                    {
                                        //add robing people here 
                                        bool UserMadeUpMind = true;
                                        while (UserMadeUpMind)
                                        {
                                        Console.WriteLine("Do you want to rob people in the bank ( as you failed to gain acces to the vault? \nYes/No?");
                                        string DidUserRobGrandMa = Console.ReadLine(); //this is where they steal money from the people inside the bank
                                        switch (DidUserRobGrandMa.ToUpper())
                                        {
                                            case "YES":
                                                {
                                                    if (HurryTime == true)
                                                    {
                                                        if (TimeGivenToDriver < 49)
                                                        {
                                                            Console.WriteLine("You loose some time robing the customers, everything is undercontrol for now...");
                                                            Console.ReadLine();
                                                            ReadTxTFiles.EnterNameofFile("DriverFail.txt");
                                                            Console.ReadLine();
                                                            UserMadeUpMind = false;

                                                            //bad- make ending bad here 

                                                            break;
                                                        }
                                                        else
                                                        {
                                                            Console.WriteLine("You loose some time robing the customers, everything is undercontrol for now...");
                                                            MoneyFromGrandMa += 10000;
                                                            if (undercovecheck > 0)
                                                            {
                                                                ReadTxTFiles.EnterNameofFile("Undercover.txt");
                                                                Console.ReadLine();
                                                                UserMadeUpMind = false;
                                                            }
                                                            else
                                                            {
                                                                var moneymade = from moneyforteam in listselected
                                                                                select moneyforteam;
                                                                foreach (var percentageofpay in moneymade)
                                                                {
                                                                    Yourtake = Yourtake + percentageofpay.Percentageofpay;

                                                                }
                                                                int MoneyForYou = 1500000 / 100 * (100 - Yourtake);
                                                           
                                                                Console.WriteLine("You made ${0}", MoneyFromGrandMa);
                                                                Console.ReadLine();
                                                                UserMadeUpMind = false;
                                                                break;
                                                            }
                                                          //  Console.ReadLine();
                                                           // UserMadeUpMind = false;
                                                            //good
                                                            break;
                                                        }
                                                        //user gets caught if time of driver is bad 
                                                    }
                                                    else
                                                    {
                                                        Console.WriteLine("You loose some time robing the customers, everything is undercontrol for now...");
                                                        MoneyFromGrandMa += 10000;
                                                        ReadTxTFiles.EnterNameofFile("DriverG.txt");
                                                        Console.ReadLine();
                                                        if (undercovecheck > 0)
                                                        {
                                                            ReadTxTFiles.EnterNameofFile("Undercover.txt");
                                                            Console.WriteLine("Jail !");
                                                            Console.ReadLine();
                                                            UserMadeUpMind = false;
                                                        }
                                                        else
                                                        {/*
                                                            var moneymade = from moneyforteam in listselected
                                                                            select moneyforteam;
                                                            foreach (var percentageofpay in moneymade)
                                                            {
                                                                Yourtake = Yourtake + percentageofpay.Percentageofpay;
                                                            }
                                                            int MoneyForYou = 1500000 / 100 * (100 - Yourtake);
                                                           */
                                                            Console.WriteLine("You made ${0}", MoneyFromGrandMa);
                                                            Console.ReadLine();
                                                            UserMadeUpMind = false;
                                                            break;
                                                        }                                                        
                                                       // Console.ReadLine();
                                                        UserMadeUpMind = false;
                                                        break;
                                                    }
                                                }
                                            case "NO":
                                                {                                            
                                                    ReadTxTFiles.EnterNameofFile("DriverG.txt");
                                                    Console.ReadLine();
                                                    UserMadeUpMind = false;
                                                    break;
                                                }
                                             default:
                                                        {
                                                            Console.WriteLine("Yes or No answer please !");
                                                            Console.ReadLine();
                                                            break;
                                                        }
                                        }
                                        }
                                    }
                                
                                       // ReadTxTFiles.EnterNameofFile("DriverG.txt");
                                       // Console.ReadLine();
                                    
                                    continue;
                                }
                                else if (TImeGivenToBankVault > 329 && TImeGivenToBankVault < 400)
                                {

                                    MakeItCool.PrintLine("You have almost in the vault.\nAll that's holding you back is a 4 Digit password.\n Your Hacker tells you that if you try a few numbers he will be able to tell you if they are part of the password or not ! \n YOu have 4 tries  "); /// now this works- make sure it followss throught with the story line. At the moment it is just stoping here .
                                    int TryCountofPAs = 4;
                                    bool PassWGuessed = true;
                                    while (PassWGuessed)
                                    {
                                        if (TryCountofPAs == 0)
                                        {
                                            Console.WriteLine("You have run out of guesses and time. \n You must now make your escape! ");

                                            Console.WriteLine("The password was {0}", finalnumber);
                                            if (TimeGivenToDriver > 39)
                                            {
                                                ReadTxTFiles.EnterNameofFile("DriverG.txt");
                                                Console.ReadLine();
                                                Console.WriteLine("But you didn't get the money");
                                                Console.ReadLine();
                                                if (undercovecheck > 0)
                                                {
                                                    ReadTxTFiles.EnterNameofFile("Undercover.txt");
                                                    break;
                                                }
                                            }
                                            else
                                            {
                                                
                                                    ReadTxTFiles.EnterNameofFile("DriverFail.txt");
                                                    Console.ReadLine();
                                                    Console.WriteLine("You go to JAIL !");
                                                    Console.ReadLine();
                                                    break;
                                                }
  
                                            PassWGuessed = false;
                                        }
                                        else
                                        {
                                            
                                            Console.WriteLine("Enter password (maximum length of 4");
                                            string bob = Console.ReadLine();
                                            if (bob.Length <= 4)
                                            {

                                                if (bob == finalnumber)
                                                {
                                                    Console.WriteLine("Password is correct!");
                                                    Console.ReadLine();
                                                    ReadTxTFiles.EnterNameofFile("Win.txt");
                                    Console.ReadLine();
                                    ReadTxTFiles.EnterNameofFile("DriverG.txt");                                  
                                    Console.ReadLine();
                                    if (undercovecheck > 0)
                                    {
                                        ReadTxTFiles.EnterNameofFile("Undercover.txt");
                                        Console.ReadLine();
                                    }
                                    else
                                    {
                                        var moneymade = from moneyforteam in listselected
                                                        select moneyforteam;
                                        foreach (var percentageofpay in moneymade)
                                        {
                                            Yourtake = Yourtake + percentageofpay.Percentageofpay;

                                        }
                                        int MoneyForYou = 1500000 / 100 * (100 - Yourtake);

                                        Console.WriteLine("You made ${0}", MoneyForYou);
                                        Console.ReadLine();
                                    }

                                                    PassWGuessed = false;
                                                    break; // make sure everything still works with the break here --------------------------------------------------------------------------------------------------------
                                                }
                                                else
                                                {
                                                    Console.WriteLine("You have not entered the correct password. \nConsult your hackes log for more information.\n Press Enter!  ");

                                                    //char[] CheckForDoublesPW = new char [4]; // maybe later 
                                                    //int Doublescount = 0;
                                                    
                                                    foreach (var number in bob)
                                                    {
                                                        int GPCount = 0;
                                                        string password = finalnumber;
                                                        if (password.Contains(number))
                                                        {
                                                            //CheckForDoublesPW[Doublescount] = number;
                                                            int PIdex = password.IndexOf(number);
                                                            Console.WriteLine("Hackers log:");
                                                            Console.WriteLine("Found! {0} in postition {1}", number, PIdex + 1);

                                                            GPCount++;
                                                        }
                                                        else
                                                        {
                                                            Console.WriteLine("Hackers log:");
                                                            Console.WriteLine("Could not find {0} in the password. Try another number!", number);

                                                        }
                                                    }
                                                }
                                                Console.WriteLine("Press Enter");
                                                Console.ReadLine();
                                                TryCountofPAs--;
                                            }
                                            else
                                            {
                                                Console.WriteLine("You have exceeded that maximum length, try again ! ");
                                            }
                                        }
                                    }
                                    break;
                                }
                                else
                                {
                                    if (HackerDidJob && GunmenDidJob == true)
                                    {
                                        ReadTxTFiles.EnterNameofFile("VaultG.txt");
                                        VaultBrokenIn = true;
                                        Console.ReadLine();
                                    }
                                    else
                                        break;     
                                }
                                if (GunmenDidJob && HackerDidJob && VaultBrokenIn == true)
                                {
                                    
                                    ReadTxTFiles.EnterNameofFile("Win.txt");
                                    Console.ReadLine();
                                    ReadTxTFiles.EnterNameofFile("DriverG.txt");                                  
                                    Console.ReadLine();
                                    if (undercovecheck > 0)
                                    {
                                        ReadTxTFiles.EnterNameofFile("Undercover.txt");
                                        Console.ReadLine();
                                    }
                                    else
                                    {
                                        var moneymade = from moneyforteam in listselected
                                                        select moneyforteam;
                                        foreach (var percentageofpay in moneymade)
                                        {
                                            Yourtake = Yourtake + percentageofpay.Percentageofpay;

                                        }
                                        int MoneyForYou = 1500000 / 100 * (100-Yourtake);
                                       
                                        Console.WriteLine("You made ${0}", MoneyForYou);
                                        Console.ReadLine();
                                        continue;
                                    }
                                    break;
                                }
                                else if (HackerDidJob == true)
                                {
                                    if (GunmenDidJob == true)
                                    {                                           
                                            //ReadTxTFiles.EnterNameofFile("VaultFail.txt");
                                            //Console.ReadLine();
                                            break;                                
                                        }
                                        else
                                        {
                                            ReadTxTFiles.EnterNameofFile("DriverG.txt");
                                            Console.ReadLine();
                                            continue;
                                        }
                                }           
                                else if (HackerDidJob == false)
                                {
                                    //ReadTxTFiles.EnterNameofFile("HackerFail.txt");
                                    //Console.ReadLine();
                                    ReadTxTFiles.EnterNameofFile("DriverFail.txt");
                                    Console.ReadLine();
                                    Console.WriteLine("Jail awaits you- ill make the ending better");
                                    Console.ReadLine();
                                    break;
                                }
                                else
                                {
                                    Console.WriteLine("Jail awaits you- ill make the ending better 2");
                                    Console.ReadLine();
                                    break;
                                }
                            }

                            
                        case "EXIT":
                            {
                                MakeItCool.PrintLine("Thank you for playing. \nFishyMonk Development \nGoodBye!. ");
                                //Console.WriteLine("Thank you for playing. \nFishyMonk Development \nGoodBye!. ");
                                Console.ReadLine();
                                startgame = false;
                                break;
                            }
                        default:
                            {
                                Console.WriteLine("Try again");
                                break;
                            }
                    }

                }
            }
        }
    }